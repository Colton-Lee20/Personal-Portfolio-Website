function SendMail()
{
    var body = document.getElementById("Message").value;
    var subjectLine = document.getElementById("Subject").value;
    window.location.href = "mailto:colton20.lee@gmail.com?subject="+subjectLine+"&body="+body;
}
